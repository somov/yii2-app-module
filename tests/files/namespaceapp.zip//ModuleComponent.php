<?php
/**
 *
 * User: develop
 * Date: 25.09.2018
 */

namespace app\modules\namespaceapp;


class ModuleComponent
{
    public static function getFoo()
    {
        return 'foo';
    }
}